export class Employee{
    EmployeeId: number;
    Name: string;
    DOB: Date;
    Gender: string;
    Area: string;
    IsAvailable: boolean;
}