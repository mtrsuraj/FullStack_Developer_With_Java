import { Employee } from '../../shared/models/Employee';

// Lab 14: Services - Injectable()

export class EmployeeService {
    

    url:string = 'http://219.65.96.170:9101/api/employee';
    
    constructor(){}
    
    // Lab 15: HTTP Service - RxJs - http.get



    // Lab 17: Forms - http.post
}