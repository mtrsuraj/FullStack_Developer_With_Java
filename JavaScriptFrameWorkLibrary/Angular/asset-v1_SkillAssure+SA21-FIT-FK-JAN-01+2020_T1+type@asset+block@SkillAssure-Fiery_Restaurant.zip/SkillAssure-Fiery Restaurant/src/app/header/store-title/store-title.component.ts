import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-store-title',
  templateUrl: './store-title.component.html',
  styleUrls: ['./store-title.component.css']
})
export class StoreTitleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
